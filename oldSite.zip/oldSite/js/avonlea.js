/*
 *File Name: avonlea.js
 *Purpose: To create my own javascript engine that will run with my main.css, html and php files.
 *Copyright (c) 2022 by William Boswall
 *No content in all or in part of this JS file shall be found anywhere else in cyberspace. No person(s) or bot(s) is or are allowed to copy this file or other js files on this site that have this comment section at the top of them. 
 *Date Created: 03/28/2022
 *Date Modified: 04/15/2022
 *Pre Version history: 0.0.1.0 alpha
 *Official version history:
*/

