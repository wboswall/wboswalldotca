<?php
namespace phpScripts;

/**
 *
 * @author wbosw
 *        
 */
class PointOfSales
{

    // TODO - Insert your code here

    /**
     */
    public function __construct()
    {

        // TODO - Insert your code here
    }

    /**
     */
    function __destruct()
    {

        // TODO - Insert your code here
    }
}

