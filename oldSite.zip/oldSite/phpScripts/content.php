<? echo ('<article class="mainPg">
					<h1>Welcome!</h1>
					<p> I am currently building the website from a custom code base and there will be more content and pages to come in the near future! </p>
                    <section class="bio">
					<p> Hello, I am William Boswall and from PEI, Canada.  I was born and raised on PEI on my family&#39;s mixed farm.  The farm comprised of potatoes, grain, beef, pigs, and dairy.  Also lots of cats to deter mice, rats and other varments.  
                    But over the years due to markets declining, we decided to call it quits around 2013 or so. </p>
                    <p> I have a BA in Arts from UPEI (Class of 2012).  I majored in Sociology and a minor in English. However I decided that I wanted to take courses in IT back in 2013.  However I decided after doing some research that web programming is the best way to go. </p>
                    <p>I then decided back in 2019 to take a course in HTML/CSS for web design at Academy of Learning and recieved the certificate in March 2020.  I plan to take more courses to stay current in the ever evolving web development field.  I am currently learning C Language, C PLus Plus, Javascript, PhP and Java. </p> 
                    </section>
                    <section class="hobbies">
                    </p> I have a few hobbies which are IT (hardware/software) and web development.  I have many passions as well such as culinary, arts, media conversion (converting physical media to digital files) and producing media content (ex. photography, video and audio), music, healthy living, and being a bookworm.</p>
                    </section>
				</article>
				');
?>
<?
echo('<article class="resume"

    </article>
');
?>