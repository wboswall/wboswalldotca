<?php
echo('<footer class="ListFooter">
<p> A special thanks to <a href="https://pixabay.com" target="_blank">Pixabay</a> for providing free images.  Much appreciated. </p>
<p> Thanks to <a href="https://realfavicongenerator.net/svg-favicon/" target="_blank">Favicon generator</a> for generating favicons for my website.</p>
<p class="email"> For email inquiries: please see <a href="contact.php" target="_blank">Contact Page</a></p>
<p> Copyright &copy; 2022 William Boswall. All rights reserved.</p>
</footer>');
?>