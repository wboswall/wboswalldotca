<?php
echo('<header class="Jumbotron">
<menu>
    <li><a href="index.php" target="_blank">Home</a></li>
    <li><a href="https://github.com/wboswall" target="_blank">My Github Repository</a></li>
  <!--<li><a href="blog.php" target="_blank">Blog</a></li>-->
 <!--<li><a href="portfolio.php" target="_blank">My Portfolio</a></li>-->
<!--<li><a href="contact.php" target="_blank">Contact</a></li>-->
</menu>
</header>');
?>