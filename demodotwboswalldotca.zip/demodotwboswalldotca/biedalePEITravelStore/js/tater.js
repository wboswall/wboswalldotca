function testJS()
{
    document.getElementById("test").innerHTML="Hello world! This is a test! from javascript!";
}